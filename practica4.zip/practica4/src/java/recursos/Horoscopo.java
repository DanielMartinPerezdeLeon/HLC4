/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursos;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author gandalfvaro
 */
public class Horoscopo {

    public static String calcularZodiaco(int dia, int mes) {

        switch (mes) {
            case 1:
                if (dia >= 21) {
                    return "Acuario";
                } else {
                    return "Capricornio";
                }
            case 2:
                if (dia >= 19) {
                    return "Piscis";
                } else {
                    return "Acuario";
                }
            case 3:
                if (dia >= 20) {
                    return "Aries";
                } else {
                    return "Piscis";
                }
            case 4:
                if (dia >= 20) {
                    return "Tauro";
                } else {
                    return "Aries";
                }
            case 5:
                if (dia >= 21) {
                    return "Geminis";
                } else {
                    return "Tauro";
                }
            case 6:
                if (dia >= 20) {
                    return "Cancer";
                } else {
                    return "Geminis";
                }
            case 7:
                if (dia >= 22) {
                    return "Leo";
                } else {
                    return "Cancer";
                }
            case 8:
                if (dia >= 21) {
                    return "Virgo";
                } else {
                    return "Leo";
                }
            case 9:
                if (dia >= 22) {
                    return "Libra";
                } else {
                    return "Virgo";
                }
            case 10:
                if (dia >= 22) {
                    return "Escorpio";
                } else {
                    return "Libra";
                }
            case 11:
                if (dia >= 21) {
                    return "Sagitario";
                } else {
                    return "Escorpio";
                }
            case 12:
                if (dia >= 22) {
                    return "Capricornio";
                } else {
                    return "Sagitario";
                }
        }
        return "fecha no válida papu :V";
    }

    public static int calculaEdad(int dia, int mes, int ano) {
        GregorianCalendar fech = new GregorianCalendar(ano, mes, dia);
        Calendar cal = Calendar.getInstance();
        int diferencia = cal.get(Calendar.YEAR) - fech.get(Calendar.YEAR);
        if (diferencia != 0 && (fech.get(Calendar.DAY_OF_YEAR) >= cal.get(Calendar.DAY_OF_YEAR))) {
            diferencia--;
        }
        return diferencia;
    }

}
