/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursos;

import java.util.ArrayList;

/**
 *
 * @author gandalfvaro
 */
public class Comida {
    
    public static ArrayList <Comida> comidas = new ArrayList<>();
    public static int posicion;
    private String nombre;
    private String pais;
    private int fechaInv;
    private int calorias;
    private String foto;

    public Comida(String nombre, String pais, int fechaInv, int calorias, String foto) {
        this.nombre = nombre;
        this.pais = pais;
        this.fechaInv = fechaInv;
        this.calorias = calorias;
        this.foto = foto;
    }

    public static ArrayList<Comida> getComidas() {
        return comidas;
    }

    public static void setComidas(ArrayList<Comida> comidas) {
        Comida.comidas = comidas;
    }

    public static int getPosicion() {
        return posicion;
    }

    public static void setPosicion(int posicion) {
        Comida.posicion = posicion;
    }
    
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public int getFechaInv() {
        return fechaInv;
    }

    public void setFechaInv(int fechaInv) {
        this.fechaInv = fechaInv;
    }

    public int getCalorias() {
        return calorias;
    }

    public void setCalorias(int calorias) {
        this.calorias = calorias;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
}
